package com.example.andrek.dialogtest;

import android.app.Activity;
import android.app.DialogFragment;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.widget.Toast;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;

/**
 * Created by AndreK on 03.12.2016.
 */

public class Bluetooth extends Thread{
    private BluetoothSocket mmSocket = null;
    private BluetoothDevice mmDevice = null;

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothServerSocket mmServerSocket = null;
    private String NAME = "KartenSpiel";
    private UUID MY_UUID;
    private String uuid_string = "54947df8-0e9e-4471-a2f9-9af509fb5889";
    private boolean OK = true;
    private boolean ConstructorFinished = false;
    Communicator communicator ;
    Set<BluetoothDevice> pairedDevices = null;
    Activity MainAct ;
    BluetoothSocket socket = null;


    public Bluetooth(Activity activity) {
        communicator = (Communicator) activity;
        MainAct = activity;
        BluetoothSocket tmp = null;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        MY_UUID = UUID.fromString(uuid_string);
        BluetoothServerSocket tmpSS = null;

        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
            // myMainActivity.myTextView.setText("Device does not support Bluetooth");
            // myMainActivity.CloseAppl();
            communicator.onDialogMessage("Device does not support Bluetooth");
            OK = false;
        }
        else if (OK && !mBluetoothAdapter.isEnabled()) {
            //myMainActivity.myTextView.setText("Bluetooth is disabled");
            //myMainActivity.CloseAppl();
            communicator.onDialogMessage("enabeling Bluetooth");
            mBluetoothAdapter.enable();
            OK = false;
        }
        if (OK) {
            pairedDevices = mBluetoothAdapter.getBondedDevices();
            // If there are paired devices
            if (pairedDevices.size() == 0) {
                communicator.onDialogMessage("There are no Paired Devices");
                OK = false;
            }
        }
        if(OK) {
            //Start Server
            try {
                tmpSS = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
            } catch (IOException e) {
                OK = false;
            }
            mmServerSocket = tmpSS;
            ConstructorFinished = true;
        }
    }

    public void run() {

        // Keep listening until exception occurs or a socket is returned
        while (true) {// sciebo
            try {
                // myMainActivity.myTextView.setText("Server waiting for Client");
                MainAct.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.onDialogMessage("+++");
                    }
                });
                socket = mmServerSocket.accept();
            } catch (IOException e) {
                //                myMainActivity.myTextView.setText("mmServerSocket.accept() failed");
                cancel();
                break;
            }
            // If a connection was accepted
            if (socket != null) {
                // Do work to manage the connection (in a separate thread)
                MainAct.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.CreateMessenger(socket, false);
                        communicator.onDialogMessage("S+++");
                    }
                });

                //connectedThread = new B_ConnectedThread(socket, myMainActivity);
                //              myMainActivity.myTextView.setText("Server B_ConnectedThread created ");
                break;
            }
        }

    }

    /** Will cancel the listening socket, and cause the thread to finish */
    public void cancel() {
        try {
            mmServerSocket.close();
        } catch (IOException e) { }
    }

    public void Challenge(Activity activity){
        //Select Device in Dialog
        android.app.FragmentManager manager = activity.getFragmentManager();

        DialogFragment newFragment = new DialogText();
        newFragment.show(manager , "dialog");

        /*
        for (BluetoothDevice btd : pairedDevices) {
            mmDevice = btd;
            break;
        }

        // Get a BluetoothSocket to connect with the given BluetoothDevice
        try {
            // MY_UUID is the app's UUID string, also used by the server code
            tmp = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            communicator.onDialogMessage("Client create socket failed");
            OK = false;
        }
        mmSocket = tmp;
        communicator.onDialogMessage("Client created socket");
        */
    }

}
