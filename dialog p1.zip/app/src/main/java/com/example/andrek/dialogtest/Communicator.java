package com.example.andrek.dialogtest;

import android.bluetooth.BluetoothSocket;

/**
 * Created by AndreK on 03.12.2016.
 */

public interface Communicator {
    public void onDialogMessage(String Message);
    public void StartBluetoothClientThread(String SelectedDevice);
    public void CreateMessenger(BluetoothSocket socket,boolean imServer);
}
