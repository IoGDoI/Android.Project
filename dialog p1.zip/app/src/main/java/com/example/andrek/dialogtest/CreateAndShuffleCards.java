package com.example.andrek.dialogtest;

/**
 * Created by AndreK on 03.12.2016.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CreateAndShuffleCards {

    public static List<Cards> CnSC() {
        // create array list object
        List<Cards> arrlist = new ArrayList<Cards>();

        // populate the list
        Cards Karte;
        Karte = new Cards("k6", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("k6", "pik");
        arrlist.add(Karte);
        Karte = new Cards("k6", "herz");
        arrlist.add(Karte);
        Karte = new Cards("k6", "karo");
        arrlist.add(Karte);

        Karte = new Cards("k7", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("k7", "pik");
        arrlist.add(Karte);
        Karte = new Cards("k7", "herz");
        arrlist.add(Karte);
        Karte = new Cards("k7", "karo");
        arrlist.add(Karte);

        Karte = new Cards("k8", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("k8", "pik");
        arrlist.add(Karte);
        Karte = new Cards("k8", "herz");
        arrlist.add(Karte);
        Karte = new Cards("k8", "karo");
        arrlist.add(Karte);

        Karte = new Cards("k9", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("k9", "pik");
        arrlist.add(Karte);
        Karte = new Cards("k9", "herz");
        arrlist.add(Karte);
        Karte = new Cards("k9", "karo");
        arrlist.add(Karte);

        Karte = new Cards("k10", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("k10", "pik");
        arrlist.add(Karte);
        Karte = new Cards("k10", "herz");
        arrlist.add(Karte);
        Karte = new Cards("k10", "karo");
        arrlist.add(Karte);

        Karte = new Cards("ka", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("ka", "pik");
        arrlist.add(Karte);
        Karte = new Cards("ka", "herz");
        arrlist.add(Karte);
        Karte = new Cards("ka", "karo");
        arrlist.add(Karte);

        Karte = new Cards("kb", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("kb", "pik");
        arrlist.add(Karte);
        Karte = new Cards("kb", "herz");
        arrlist.add(Karte);
        Karte = new Cards("kb", "karo");
        arrlist.add(Karte);

        Karte = new Cards("kd", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("kd", "pik");
        arrlist.add(Karte);
        Karte = new Cards("kd", "herz");
        arrlist.add(Karte);
        Karte = new Cards("kd", "karo");
        arrlist.add(Karte);

        Karte = new Cards("kk", "kreuz");
        arrlist.add(Karte);
        Karte = new Cards("kk", "pik");
        arrlist.add(Karte);
        Karte = new Cards("kk", "herz");
        arrlist.add(Karte);
        Karte = new Cards("kk", "karo");
        arrlist.add(Karte);

        // shuffle the list
        Collections.shuffle(arrlist);
        System.out.println(arrlist.size());
        // Print shuffled list
        // for(int i = 0; i<arrlist.size();i++){
        // System.out.println("KARTE "+i+" : "+arrlist.get(i).getKarte()+" Farbe
        // : "+arrlist.get(i).getFarbe()+" Wert : "+arrlist.get(i).getWert()+
        // "Prio : " +arrlist.get(i).getPrio());
        // }

        return arrlist;
    }
}
