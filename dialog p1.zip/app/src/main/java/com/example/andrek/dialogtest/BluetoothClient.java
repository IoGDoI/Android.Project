package com.example.andrek.dialogtest;

import android.app.Activity;
import android.app.DialogFragment;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.SystemClock;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;

/**
 * Created by AndreK on 04.12.2016.
 */

public class BluetoothClient extends Thread {
    private BluetoothSocket mmSocket = null;
    private BluetoothDevice mmDevice = null;

    private BluetoothAdapter mBluetoothAdapter;
    private UUID MY_UUID;
    private String uuid_string = "54947df8-0e9e-4471-a2f9-9af509fb5889";
    private boolean OK = true;
    public boolean ConstructorFinished = false;
    Communicator communicator ;
    public Set<BluetoothDevice> pairedDevices = null;
    Activity MainAct ;
    public String SelectedDevice = "";


    public BluetoothClient(Activity activity) {
        communicator = (Communicator) activity;
        MainAct = activity;
        BluetoothSocket tmp = null;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        MY_UUID = UUID.fromString(uuid_string);
        BluetoothServerSocket tmpSS = null;

        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
            // myMainActivity.myTextView.setText("Device does not support Bluetooth");
            // myMainActivity.CloseAppl();
            communicator.onDialogMessage("Device does not support Bluetooth");
            OK = false;
        }
        else if (OK && !mBluetoothAdapter.isEnabled()) {
            //myMainActivity.myTextView.setText("Bluetooth is disabled");
            //myMainActivity.CloseAppl();
            communicator.onDialogMessage("enabeling Bluetooth");
            mBluetoothAdapter.enable();
            OK = false;
        }
        if (OK) {
            pairedDevices = mBluetoothAdapter.getBondedDevices();
            // If there are paired devices
            if (pairedDevices.size() == 0) {
                communicator.onDialogMessage("There are no Paired Devices");
                OK = false;
            }
        }
        if(OK) {
            ConstructorFinished = true;
        }
    }

    public void run() {
           // mBluetoothAdapter.cancelDiscovery();
            try {
                for (BluetoothDevice btd : pairedDevices) {
                    if (btd.getName().equals(SelectedDevice)) {
                        mmDevice = btd;
                        break;
                    }
                }
                mmSocket = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
                MainAct.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.onDialogMessage("Client is waiting for connection");
                    }
                });
                mmSocket.connect();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and get out
                try {
                    MainAct.runOnUiThread(new Runnable() {
                        public void run() {
                            communicator.onDialogMessage("Client socket connect failed");
                        }
                    });
                    mmSocket.close();
                } catch (IOException closeException) {
                }
                return;
            }

        MainAct.runOnUiThread(new Runnable() {
            public void run() {
                communicator.CreateMessenger(mmSocket, true);
                communicator.onDialogMessage("S+++");
            }
        });
        }

    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) { }
    }
}
