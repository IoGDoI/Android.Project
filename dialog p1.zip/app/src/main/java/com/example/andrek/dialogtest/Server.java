package com.example.andrek.dialogtest;

import java.util.List;

/**
 * Created by AndreK on 04.12.2016.
 */

public class Server {
    Messenger messenger = null;

    public Server(){

    }

    public void SendCards (String UsernameEnemy, String Username, List<Cards> Stack, Boolean gepasst, Boolean gespielt, Boolean geschlagen){
        String Message = "receiveCards;";
        Message += messenger.encodeCardsArray(Stack);
        Message += messenger.boolToString(gepasst);
        Message += messenger.boolToString(gespielt);
        Message += messenger.boolToString(geschlagen);
        messenger.write(Message);
    }

    public void Gewonnen (String Username , boolean Intern){
        String Message = "CGewonnen";
        messenger.write(Message);
    }

    public void Verloren (String Username , boolean Intern){
        String Message = "CVerloren";
        messenger.write(Message);
    }

    public void Aufgeben (String Username, String UsernameEnemy){
        String Message = "EnemySurrendered";
        messenger.write(Message);
    }

    public void getNewStack36(String Gegner, String User, Boolean gewonnen){
        String Message = "setNewStack36;";
        List<Cards> newStack = CreateAndShuffleCards.CnSC();
        //todo----------------------------
        /*
        for (int i = 0; i < ControllerServerScreen.Angemeldet.size(); i++) {
            if (ControllerServerScreen.Angemeldet.get(i).getUsername().equals(User)) {
                ControllerServerScreen.Angemeldet.get(i).getMRC().setNewStack36(newStack, gewonnen);
            }
            if (ControllerServerScreen.Angemeldet.get(i).getUsername().equals(Gegner)) {
                ControllerServerScreen.Angemeldet.get(i).getMRC().setNewStack36(newStack, !gewonnen);
            }
        }
        */
        messenger.write(Message);
    }
}
