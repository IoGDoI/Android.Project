package com.example.andrek.dialogtest;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by AndreK on 03.12.2016.
 */

public class DialogChallenge extends DialogFragment{
    Communicator communicator ;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        communicator = (Communicator) activity ;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        setCancelable(false);
        final String[] stringArray;
        stringArray = getArguments().getStringArray("Devices");
        builder.setItems(stringArray, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                communicator.onDialogMessage("Selected Item : "+ stringArray[i]);
                communicator.StartBluetoothClientThread(stringArray[i]);
                dismiss();
            }
        });
        builder.setTitle("Select Device");
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
