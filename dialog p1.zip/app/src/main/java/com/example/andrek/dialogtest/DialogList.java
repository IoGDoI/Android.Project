package com.example.andrek.dialogtest;

/**
 * Created by AndreK on 03.12.2016.
 */

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Created by AndreK on 03.12.2016.
 */

public class DialogList extends DialogFragment {
    Communicator communicator ;
    CharSequence[] Sarray  = new CharSequence[3];

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        communicator = (Communicator) activity ;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        Sarray[0] = "wut";
        Sarray[1] = "the";
        Sarray[2] = "fuck";
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        setCancelable(false);
        builder.setItems(Sarray, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                communicator.onDialogMessage("Selected Item : "+ Sarray[i]);
                dismiss();
            }
        });
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //Toast.makeText(getActivity(),"OK clicked" ,Toast.LENGTH_LONG).show();
                        communicator.onDialogMessage("OK clicked");
                        dismiss();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //Toast.makeText(getActivity(),"CANCEL clicked" ,Toast.LENGTH_LONG).show();
                        communicator.onDialogMessage("Cancle clicked");
                        dismiss();
                    }
                });
        builder.setTitle("My Dialog");
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
