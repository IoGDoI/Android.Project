package com.example.andrek.dialogtest;

import android.app.DialogFragment;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.provider.ContactsContract;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements Communicator {
    public Button Bt;
    public  Button Bt2;
    public Button Bt3;
    public Button Bt4;
    public Button Bt5;
    public Button Bt6;
    public Button Bt7;
    public Button Bt8;
    public TextView Tw;
    private Messenger myMessenger;
    Server server = null;
    Client client = null;
    private List<Cards> Cards36 = new ArrayList<Cards>();
    BluetoothClient newBC;
    Bluetooth newB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bt = (Button) findViewById(R.id.Button);
        Bt.setOnClickListener(BtClick);
        Bt2 = (Button) findViewById(R.id.button2);
        Bt2.setOnClickListener(Bt2Click);
        Bt3 = (Button) findViewById(R.id.button3);
        Bt3.setOnClickListener(Bt3Click);
        Bt4 = (Button) findViewById(R.id.button4);
        Bt4.setOnClickListener(Bt4Click);
        Bt5 = (Button) findViewById(R.id.button5);
        Bt5.setOnClickListener(Bt5Click);
        Bt6 = (Button) findViewById(R.id.button6);
        Bt6.setOnClickListener(Bt6Click);
        Bt7 = (Button) findViewById(R.id.button7);
        Bt7.setOnClickListener(Bt7Click);
        Bt8 = (Button) findViewById(R.id.button8);
        Bt8.setOnClickListener(Bt8Click);
        Tw = (TextView) findViewById(R.id.textView);
    }


    private View.OnClickListener BtClick = new View.OnClickListener() {
        public void onClick(View v) {
            android.app.FragmentManager manager = getFragmentManager();

            DialogFragment newFragment = new DialogTest();
            newFragment.show(manager , "dialog");
        }
    };
    private View.OnClickListener Bt3Click = new View.OnClickListener() {
        public void onClick(View v) {
            android.app.FragmentManager manager = getFragmentManager();

            DialogFragment newFragment = new DialogText();
            newFragment.show(manager , "dialog");
        }
    };

    private View.OnClickListener Bt2Click = new View.OnClickListener() {
        public void onClick(View v) {
            android.app.FragmentManager manager = getFragmentManager();

            DialogFragment newFragment = new DialogList();
            newFragment.show(manager , "dialog");
        }
    };

    private View.OnClickListener Bt4Click = new View.OnClickListener() {
        public void onClick(View v) {
            android.app.FragmentManager manager = getFragmentManager();

            DialogFragment newFragment = new DialogPass();
            Bundle args = new Bundle();
            args.putString("Name", "Andre");
            newFragment.setArguments(args);
            newFragment.show(manager , "dialog");
        }
    };

    private View.OnClickListener Bt5Click = new View.OnClickListener() {
        public void onClick(View v) {
            Cards36 = CreateAndShuffleCards.CnSC();
            byte[] buffer = new byte[1024];
            String Message ;

            buffer = encode("Hello World");
            Message = decode(buffer);
            Toast.makeText(MainActivity.this ,Message ,Toast.LENGTH_SHORT).show();

            //getNewStack36(EnemyUser, UserAcc.getUsername(), UserAmZugLetztePartie);
            buffer = encode("getNewStack36;Kartoffel;UserPommes;True");
            Message = decode(buffer);
            decodeMessage(Message);

            //RemoteServer1.Verloren(UserAcc.getUsername(), false);
            //RemoteServer1.Gewonnen(EnemyUser, false);
            buffer = encode("Verloren;Wer  ner;True");
            Message = decode(buffer);
            decodeMessage(Message);

            buffer = encode("Gewonnen;Wer  ner;false");
            Message = decode(buffer);
            decodeMessage(Message);

            //RemoteServer1.SendCards(EnemyUser, UserAcc.getUsername(), UserStapelSpielen, true, false,false);
            Cards36.remove(2);
            Cards36.remove(3);
            Cards36.remove(4);
            Cards36.remove(10);
            buffer = encode("SendCards;Wer  ner;Donnie;" + encodeCardsArray(Cards36) + boolToString(true) + boolToString(false) + boolToString(false));
            Message = decode(buffer);
            decodeMessage(Message);

        }
    };

    private View.OnClickListener Bt6Click = new View.OnClickListener() {
        public void onClick(View v) {
            newB = new Bluetooth(MainActivity.this);
            newB.start();
        }
    };

    private View.OnClickListener Bt7Click = new View.OnClickListener() {
        public void onClick(View v) {
            newBC = new BluetoothClient(MainActivity.this);
            if (newBC.ConstructorFinished) {
                android.app.FragmentManager manager = getFragmentManager();

                DialogFragment newFragment = new DialogChallenge();
                Bundle args = new Bundle();
                String[] stringArray = new String[newBC.pairedDevices.size()];
                int i = 0;

                for (BluetoothDevice btd : newBC.pairedDevices) {
                    stringArray[i] = btd.getName();
                    i++;
                }
                args.putStringArray("Devices", stringArray);
                newFragment.setArguments(args);

                newFragment.show(manager, "ChallengeDialog");
            }
        }
    };

    private View.OnClickListener Bt8Click = new View.OnClickListener() {
        public void onClick(View v) {
            if(myMessenger != null){
                List<Cards> Stack = new ArrayList<Cards>();
                Stack = CreateAndShuffleCards.CnSC();
                for (int i=0;i<15;i++){
                    Stack.remove(i);
                }
                String Message = "receiveCards;";
                Message += myMessenger.encodeCardsArray(Stack);
                Message += myMessenger.boolToString(true);
                Message += myMessenger.boolToString(false);
                Message += myMessenger.boolToString(true);
                myMessenger.write(Message);
            }
        }
    };

    public String boolToString(boolean bool){
        if (bool == true){
            return "True;";
        }
        else if (bool == false){
            return "False;";
        }
        else {
            Toast.makeText(MainActivity.this ,"boolToString fatal error" ,Toast.LENGTH_SHORT).show();
            return "False;";
        }
    }

    public boolean stringToBool(String bool){
        if (bool.equals("True")){
            return true;
        }
        else if (bool.equals("False")){
            return false;
        }
        else {
            Toast.makeText(MainActivity.this ,"stringToBool fatal error" ,Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public String encodeCards (Cards card){
        return (card.getKarte() +":"+ card.getFarbe() + ":");
    }

    public Cards decodeCards(String card){
        String[] parts = card.split(":");
        return new Cards(parts[0],parts[1]);
    }

    public String encodeCardsArray(List<Cards> cards){
        String result = "";
        for (int i = 0 ;i < cards.size() ;i++){
            result += encodeCards(cards.get(i));
        }
        result += ";";
        return result;
    }

    public List<Cards> decodeCardsArray(String[] cards){
        List<Cards> result = new ArrayList<Cards>();
        for (int i = 0 ;i < cards.length;i++){
            if (cards[i] == null ||cards[i].equals("") ){
                break;
            }
            result.add(decodeCards(cards[i]));
        }
        return result;
    }

    public List<Cards> decodeCardsArrayEazy(String[] cards){
        List<Cards> result = new ArrayList<Cards>();
        for (int i = 0 ;i < cards.length;i+=2){
            if (cards[i] == null ||cards[i].equals("") ){
                break;
            }
            result.add(new Cards(cards[i],cards[i+1]));
        }
        return result;
    }

    private void decodeMessage(String message) {
        String[] parts = message.split(";");
        boolean temp = false;
        if (parts[0].equals("getNewStack36")){
            if (parts[3].equals("True")){
                temp = true;
            }
            else if (parts[3].equals("False")){
                temp = false;
            }
            getNewStack36(parts[1],parts[2],temp);
        }
        else if (parts[0].equals("Gewonnen")){
            if (parts[2].equals("True")){
                temp = true;
            }
            else if (parts[2].equals("False")){
                temp = false;
            }
            Gewonnen(parts[1],temp);
        }
        else if (parts[0].equals("Verloren")){
            if (parts[2].equals("True")){
                temp = true;
            }
            else if (parts[2].equals("False")){
                temp = false;
            }
            Verloren(parts[1],temp);
        }
        else if (parts[0].equals("SendCards")){
            String[] tempParts  = new String[72];
            int tempInt = 3;
           // public void SendCards(String UsernameEnemy,String Username, List<Cards> Stack, Boolean gepasst, Boolean gespielt, Boolean geschlagen)
            tempParts = parts[3].split(":");
            SendCards(parts[1],parts[2],decodeCardsArrayEazy(tempParts),stringToBool(parts[4]),stringToBool(parts[5]),stringToBool(parts[6]));
        }
    }

    private String decode(byte[] buffer) {
        String myString = new String(buffer);
        return myString;
    }

    @Override
    public void onDialogMessage(String Message) {
        Tw.setText(Message);
    }

    @Override
    public void StartBluetoothClientThread(String SelectedDevice) {
        newBC.SelectedDevice = SelectedDevice;
        newBC.start();
    }

    @Override
    public void CreateMessenger(BluetoothSocket socket,boolean imServer) {
        if (imServer){
            server = new Server();
        }
        client = new Client(MainActivity.this);
        myMessenger = new Messenger(socket,MainActivity.this,imServer,server,client);
        myMessenger.start();
    }

    public byte[] encode(String myMessage) {
            byte[] buffer = new byte[1024];
            buffer = myMessage.getBytes();
            return buffer;
    }

    public void getNewStack36(String Enemy , String User, boolean UserAmZugLetztePartie ){
        Toast.makeText(MainActivity.this ,"getNewStack36 called " +  Enemy + " " + User + " " + UserAmZugLetztePartie ,Toast.LENGTH_LONG).show();
    }

    public void Gewonnen(String User , boolean Intern ){
        Toast.makeText(MainActivity.this ,"Gewonnen called " +  User + " " + Intern ,Toast.LENGTH_SHORT).show();
    }

    public void Verloren(String User , boolean Intern ){
        Toast.makeText(MainActivity.this ,"Verloren called " +  User + " " +  Intern ,Toast.LENGTH_SHORT).show();
    }

    public void SendCards(String UsernameEnemy,String Username, List<Cards> Stack, Boolean gepasst, Boolean gespielt, Boolean geschlagen){
        String text = "";
        for (int i = 0 ; i< Stack.size(); i++){
            text += Stack.get(i).getKarte() + " " + Stack.get(i).getFarbe() + " Prio : " + Stack.get(i).getPrio()+ " Wert : " + Stack.get(i).getWert() + " ";
        }
        Tw.setText(text);
        Toast.makeText(MainActivity.this ,"SendCards " +  UsernameEnemy + " " +  Username + " " + gepasst + " " +gespielt + " " + geschlagen + Stack.get(0).getKarte()
                + " " + Stack.get(0).getFarbe() + " " + Stack.get(0).getPrio()+ " " + Stack.get(0).getWert(),Toast.LENGTH_SHORT).show();
    }
}
