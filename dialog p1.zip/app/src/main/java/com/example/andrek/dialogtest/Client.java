package com.example.andrek.dialogtest;

import android.app.Activity;

import java.util.List;

/**
 * Created by AndreK on 04.12.2016.
 */

public class Client {
    Activity activity;
    Communicator communicator;
    public Client(Activity myActivity){
        activity = myActivity;
        communicator = (Communicator) activity;
    }

    void setNewStack36(List<Cards> Stack, Boolean AmZug){
        communicator.onDialogMessage("setNewStack36");
    }
    void SpielGefunden(List<Cards> Stack, String Gegner, Boolean AmZug){
        communicator.onDialogMessage("SpeilGefunden");
    }
    void receiveCards(List<Cards> Stack, Boolean gepasst, Boolean gespielt, Boolean geschlagen){
        communicator.onDialogMessage("receiveCards");
    }
    void CGewonnen(){
        communicator.onDialogMessage("CGewonnen");
    }
    void CVerloren() {
        communicator.onDialogMessage("CVerloren");
    }
    void EnemySurrendered() {
        communicator.onDialogMessage("EnemySurrendered");
    }
}
