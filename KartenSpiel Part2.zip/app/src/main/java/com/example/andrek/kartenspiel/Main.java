package com.example.andrek.kartenspiel;


import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.res.Resources;
import android.media.Image;
import android.renderscript.Allocation;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


public class Main extends AppCompatActivity implements Communicator {
    private List<Cards> Stapel = new ArrayList<Cards>();
    private List<Cards> UserStapel = new ArrayList<Cards>();
    private List<Cards> EnemyStapel = new ArrayList<Cards>();
    private List<Cards> UserStapelSpielen = new ArrayList<Cards>();
    private List<Cards> EnemyStapelSpielen = new ArrayList<Cards>();
    private List<Cards> UserAblage = new ArrayList<Cards>();
    private List<Cards> EnemyAblage = new ArrayList<Cards>();
    private String SelectedColor = "";
    private boolean UserAmZug;
    private boolean UserAngriff;
    private boolean UserVerteidigung;
    private boolean UserAmZugLetztePartie;
    public static User UserAcc;
    public String EnemyUser;
    public String User;
    Button Menu1;
    Button Menu2;
    Button Spielen;
    Button Schlagen;
    Button Passen;
    ImageButton StapelB;
    ImageButton Joker;
    ImageButton UserCard1;
    ImageButton UserCard2;
    ImageButton UserCard3;
    ImageButton UserCard4;
    ImageButton EnemyCard1;
    ImageButton EnemyCard2;
    ImageButton EnemyCard3;
    ImageButton EnemyCard4;
    ImageButton EnemyCard_Played1;
    ImageButton EnemyCard_Played2;
    ImageButton EnemyCard_Played3;
    ImageButton EnemyCard_Played4;
    ImageButton UserCard_Played1;
    ImageButton UserCard_Played2;
    ImageButton UserCard_Played3;
    ImageButton UserCard_Played4;
    ImageButton UserStapelB;
    ImageButton EnemyStapelB;


    TextView PointsEnemy;
    TextView PointsUser;
    TextView EnemyName;
    TextView UserName;
    TextView Tipp;

    private String TrumpfkartenFarbe;
    private boolean tempAlreadySelected1 = false;
    private boolean tempAlreadySelected2 = false;
    private boolean tempAlreadySelected3 = false;
    private boolean tempAlreadySelected4 = false;
    private boolean ImSpiel = false;
    private int PPUser =0;
    private int PPEnemy =0;
    DialogManager dialogManager = null;
    BluetoothClientSocket_T BCS_T = null;
    BluetoothServerSocket_T BSS_T = null;
    Server server = null;
    Client client = null;
    Messenger messenger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainlayout);
        Init();
    }

    public void initialize() {
        ResetSelected();
        ResetVisibility();
        HidePunkteAnzeigeButtons();
        Tipp.setText("Wäheln sie zwischen Bluetooth und Internet");
        Menu1.setText("Bluetooth");
        Menu2.setText("Internet");
        dialogManager = new DialogManager(Main.this,getFragmentManager());
        dialogManager.setUsernameDialog();
    }

    public void SmallInitialize(Boolean Gewonnen, Boolean Verloren) {
                 if (Gewonnen) {
                    //todo dialog
                }else if (Verloren) {
                     //todo dialog
                 }
                ImSpiel = false;
                ClearStacks();
                ResetSelected();
                ResetVisibility();
                ResetPunkte(true);
                HidePunkteAnzeigeButtons();
                Tipp.setText("Drьcken sie Spiel Hosten");
    }

    private void ResetPunkte(boolean Spiel) {
        PPUser = 0;
        PPEnemy =0 ;
        if (Spiel) {
            PointsUser.setText("0");
            PointsEnemy.setText("0");
        }
    }

    private void InitAmZug(boolean UAmZug) {
        if (UAmZug) {
            Tipp.setText("Nдchste Partie hat angefangen. User am Zug!");
            KartenAusteilen(true);
            UserAmZug = true;
            UserAngriff = true;
            UserVerteidigung = false;
        } else {
            Tipp.setText("Nдchste Partie hat angefangen. Enemy am Zug!");
            KartenAusteilen(false);
            UserAmZug = false;
            UserAngriff = false;
            UserVerteidigung = false;
        }

    }

    private void KartenAusteilen(boolean UserZuerst) {
        int size = Stapel.size();
        if (UserZuerst) {
            for (int a = 0; a < size; a++) {
                if (a == 8 || ((UserStapel.size() == 4) && (EnemyStapel.size() == 4))) {
                    break;
                }
                if ((a % 2) == 0) {
                    UserStapel.add(Stapel.get(0));
                } else {
                    EnemyStapel.add(Stapel.get(0));
                }
                Stapel.remove(0);
            }
        } else {
            for (int a = 0; a < size; a++) {
                if (a == 8 || ((UserStapel.size() == 4) && (EnemyStapel.size() == 4))) {
                    break;
                }
                if ((a % 2) == 0) {
                    EnemyStapel.add(Stapel.get(0));
                } else {
                    UserStapel.add(Stapel.get(0));
                }
                Stapel.remove(0);
            }
        }
    }

    private void HidePunkteAnzeigeButtons() {
        Spielen.setVisibility(View.INVISIBLE);
        Schlagen.setVisibility(View.INVISIBLE);
        Passen.setVisibility(View.INVISIBLE);
        PointsEnemy.setVisibility(View.INVISIBLE);
        PointsUser.setVisibility(View.INVISIBLE);
        EnemyName.setVisibility(View.INVISIBLE);
        UserName.setVisibility(View.INVISIBLE);
    }

    private void ResetSelected() {
        tempAlreadySelected1 = false;
        tempAlreadySelected2 = false;
        tempAlreadySelected3 = false;
        tempAlreadySelected4 = false;

    }

    private void Init(){
        Menu1 =  (Button) findViewById (R.id.SpielSuchen_button);
        Menu2 =  (Button) findViewById (R.id.SpielHosten_button);
        Menu1.setOnClickListener(Menu1Click);
        Menu2.setOnClickListener(Menu2Click);
        PointsEnemy = (TextView) findViewById(R.id.PointsEnemy_textView);
        PointsUser = (TextView) findViewById(R.id.PointUser_textView);
        UserName = (TextView) findViewById(R.id.UserName_textView);
        EnemyName = (TextView) findViewById(R.id.EnemyName_textView);
        Tipp = (TextView) findViewById(R.id.Tipp);
        StapelB = (ImageButton) findViewById(R.id.Stapel_button);
        Joker = (ImageButton) findViewById(R.id.Joker_button);
        StapelB.setOnClickListener(Stapel_Click);
        Joker.setOnClickListener(Joker_Click);
        UserCard1 = (ImageButton) findViewById(R.id.UserCard1_button);
        UserCard2 = (ImageButton) findViewById(R.id.UserCard2_button);
        UserCard3 = (ImageButton) findViewById(R.id.UserCard3_button);
        UserCard4 = (ImageButton) findViewById(R.id.UserCard4_button);
        EnemyCard1 = (ImageButton) findViewById(R.id.EnemyCard1_button);
        EnemyCard2 = (ImageButton) findViewById(R.id.EnemyCard2_button);
        EnemyCard3 = (ImageButton) findViewById(R.id.EnemyCard3_button);
        EnemyCard4 = (ImageButton) findViewById(R.id.EnemyCard4_button);
        EnemyCard_Played1 = (ImageButton) findViewById(R.id.EnemyCard_Played1_button);
        EnemyCard_Played2 = (ImageButton) findViewById(R.id.EnemyCard_Played2_button);
        EnemyCard_Played3 = (ImageButton) findViewById(R.id.EnemyCard_Played3_button);
        EnemyCard_Played4 = (ImageButton) findViewById(R.id.EnemyCard_Played4_button);
        UserCard_Played1 = (ImageButton) findViewById(R.id.UserCard_Played1_button);
        UserCard_Played2 = (ImageButton) findViewById(R.id.UserCard_Played2_button);
        UserCard_Played3 = (ImageButton) findViewById(R.id.UserCard_Played3_button);
        UserCard_Played4 = (ImageButton) findViewById(R.id.UserCard_Played4_button);
        UserStapelB = (ImageButton) findViewById(R.id.UserStapel);
        EnemyStapelB = (ImageButton) findViewById(R.id.EnemyStapel);
        UserStapelB.setOnClickListener(UserStapelB_Click);
        EnemyStapelB.setOnClickListener(EnemyStapelB_Click);
        UserCard1.setOnClickListener(UserCard1_Click);
        UserCard2.setOnClickListener(UserCard2_Click);
        UserCard3.setOnClickListener(UserCard3_Click);
        UserCard4.setOnClickListener(UserCard4_Click);
        EnemyCard1.setOnClickListener(EnemyCard_Click);
        EnemyCard2.setOnClickListener(EnemyCard_Click);
        EnemyCard3.setOnClickListener(EnemyCard_Click);
        EnemyCard4.setOnClickListener(EnemyCard_Click);
        EnemyCard_Played1.setOnClickListener(EnemyCardPlayed_Click);
        EnemyCard_Played2.setOnClickListener(EnemyCardPlayed_Click);
        EnemyCard_Played3.setOnClickListener(EnemyCardPlayed_Click);
        EnemyCard_Played4.setOnClickListener(EnemyCardPlayed_Click);
        UserCard_Played1.setOnClickListener(UserCardPlayed_Click);
        UserCard_Played2.setOnClickListener(UserCardPlayed_Click);
        UserCard_Played3.setOnClickListener(UserCardPlayed_Click);
        UserCard_Played4.setOnClickListener(UserCardPlayed_Click);
        Spielen = (Button) findViewById(R.id.Spielen);
        Schlagen = (Button) findViewById(R.id.Schlagen);
        Passen = (Button) findViewById(R.id.Passen);
        Spielen.setOnClickListener(SpielenClick);
        Schlagen.setOnClickListener(SchlagenClick);
        Passen.setOnClickListener(PassenClick);
        initialize();
    }
    private View.OnClickListener SpielenClick = new View.OnClickListener() {
        public void onClick(View v) {
            Boolean tempB = false;
            Boolean RichtigeAuswahl = true;
            if (UserAmZug && UserAngriff && !((Stapel.size() >= 2) && (UserStapel.size() < 4))) {
                if (EnemyStapelSpielen.isEmpty()) {
                    if (UserStapelSpielen.isEmpty()) {
                        Tipp.setText("Wдhlen sie Karten zum spielen aus.");
                    } else {
                        SelectedColor = UserStapelSpielen.get(0).getFarbe();
                        for (int i = 0; i < UserStapelSpielen.size(); i++) {
                            if (SelectedColor != UserStapelSpielen.get(i).getFarbe()) {
                                RichtigeAuswahl = false;
                            }
                        }
                        if (RichtigeAuswahl) {
                            for (int a = 0; a < UserStapelSpielen.size(); a++) {
                                for (int i = 0; i < UserStapel.size(); i++) {
                                    if (UserStapel.get(i).getKarte().equals(UserStapelSpielen.get(a).getKarte())
                                            && UserStapel.get(i).getFarbe().equals(UserStapelSpielen.get(a).getFarbe())) {
                                        UserStapel.remove(i);
                                    }
                                }
                            }
                            try {
                                System.out.println("RemoteServer1.SendCards Spielen");
                                messenger.SendCards(EnemyUser, UserAcc.getUsername(), UserStapelSpielen, false, true,
                                        false);
                            } catch (Exception e) {
                                System.out.println("RemoteServer1.SendCards failed");
                            }
                            KartenAnzeigen();
                            UserAmZug = false;
                            UserAngriff = false;
                            UserVerteidigung = false;
                        } else {
                            Tipp.setText("Ihre Auswahl ist nicht korrekt. Nur Karten einer Farbe beim Angriff erlaubt.");
                        }
                    }
                } else {
                    Tipp.setText("EnemyStapelSpielen ist nicht leer!");
                }
            } else {
                if (!UserAmZug) {
                    Tipp.setText("Sie sind nicht am Zug!");
                } else if (!UserAngriff) {
                    Tipp.setText("Sie greifen nicht an und mьssen sich verteidigen(Passen oder Schlagen)");
                } else if (!((Stapel.size() >= 2) && (UserStapel.size() < 4))) {
                    Tipp.setText("Sie mьssen zuerst neue Karten vom Stapel nehmen");
                }
            }

        }
    };
    private View.OnClickListener SchlagenClick = new View.OnClickListener() {
        public void onClick(View v) {
            Boolean tempB = false;
            if (UserAmZug && UserVerteidigung && !((Stapel.size() >= 2) && (UserStapel.size() < 4))) {
                if (UserStapelSpielen.size() == EnemyStapelSpielen.size()) {
                    boolean RichtigeAuswahl = true;
                    for (int i = 0; i < UserStapelSpielen.size(); i++) {
                        if (!(KartenOK(EnemyStapelSpielen.get(i), UserStapelSpielen.get(i)))) {
                            RichtigeAuswahl = false;
                            Tipp.setText("Ihre Auswahl ist falsch. Karte :" + UserStapelSpielen.get(i).getKarte()
                                    + "Schlдgt nicht die Karte :" + EnemyStapelSpielen.get(i).getKarte());
                        }
                    }
                    if (RichtigeAuswahl) {
                        for (int a = 0; a < UserStapelSpielen.size(); a++) {
                            for (int i = 0; i < UserStapel.size(); i++) {
                                if (UserStapel.get(i).getKarte().equals(UserStapelSpielen.get(a).getKarte())
                                        && UserStapel.get(i).getFarbe().equals(UserStapelSpielen.get(a).getFarbe())) {
                                    UserStapel.remove(i);
                                }
                            }
                        }
                        try {
                            System.out.println("RemoteServer1.SendCards Schlagen");
                            messenger.SendCards(EnemyUser, UserAcc.getUsername(), UserStapelSpielen, false, false,
                                    true);
                        } catch (Exception e) {
                            System.out.println("RemoteServer1.SendCards failed");

                        }
                        for (int i = 0; i < UserStapelSpielen.size(); i++) {
                            UserAblage.add(UserStapelSpielen.get(i));
                        }
                        for (int i = 0; i < EnemyStapelSpielen.size(); i++) {
                            UserAblage.add(EnemyStapelSpielen.get(i));
                        }
                        KartenAnzeigen();
                        UserAmZug = true;
                        UserAngriff = true;
                        UserVerteidigung = false;
                        Tipp.setText("Sie sind am Zug. Greifen Sie an.");
                    }
                } else {
                    Tipp.setText(
                            "Ihre Auswahl ist nicht korrekt. Die Anzahl der ausgewдhlten Karten muss gleich groЯ sein mit der Anzahl der Karten mit denen der Gegner angreift.");
                }
            } else {
                if (!UserAmZug) {
                    Tipp.setText("Sie sind nicht am Zug!");
                } else if (!UserVerteidigung) {
                    Tipp.setText("Sie verteidigen sich nicht und mьssen angeifen (spielen)");
                } else if (!((Stapel.size() >= 2) && (UserStapel.size() < 4))) {
                    Tipp.setText("Sie mьssen zuerst neue Karten vom Stapel nehmen");
                }
            }
        }
    };

    private boolean KartenOK(Cards KarteV, Cards KarteA) {
        if ((!KarteV.getFarbe().equals(TrumpfkartenFarbe)) && (KarteA.getFarbe().equals(TrumpfkartenFarbe))) {
            return true;
        }
        if ((KarteV.getFarbe().equals(KarteA.getFarbe()))) {
            if (KarteV.getPrio() < KarteA.getPrio()) {
                return true;
            } else if (KarteV.getPrio() > KarteA.getPrio()) {
                return false;
            }
        }
        return false;
    }

    private View.OnClickListener PassenClick = new View.OnClickListener() {
        public void onClick(View v) {
            Boolean tempB = false;
            if (UserAmZug && UserVerteidigung && !((Stapel.size() >= 2) && (UserStapel.size() < 4))) {
                if (UserStapelSpielen.isEmpty()) {
                    Tipp.setText("Wдhlen sie Karten zum spielen aus.");
                } else {
                    if (UserStapelSpielen.size() == EnemyStapelSpielen.size()) {
                        for (int a = 0; a < UserStapelSpielen.size(); a++) {
                            for (int i = 0; i < UserStapel.size(); i++) {
                                if (UserStapel.get(i).getKarte().equals(UserStapelSpielen.get(a).getKarte())
                                        && UserStapel.get(i).getFarbe().equals(UserStapelSpielen.get(a).getFarbe())) {
                                    UserStapel.remove(i);
                                }
                            }
                        }
                        try {
                            System.out.println("RemoteServer1.SendCards Passen");
                            messenger.SendCards(EnemyUser, UserAcc.getUsername(), UserStapelSpielen, true, false,
                                    false);
                        } catch (Exception e) {
                            System.out.println("RemoteServer1.SendCards failed");
                        }
                        for (int i = 0; i < UserStapelSpielen.size(); i++) {
                            EnemyAblage.add(UserStapelSpielen.get(i));
                        }
                        for (int i = 0; i < EnemyStapelSpielen.size(); i++) {
                            EnemyAblage.add(EnemyStapelSpielen.get(i));
                        }
                        KartenAnzeigen();
                        UserAmZug = false;
                        UserAngriff = false;
                        UserVerteidigung = false;
                    } else {
                        Tipp.setText(
                                "Ihre Auswahl ist nicht korrekt. Die Anzahl der ausgewдhlten Karten muss gleich groЯ sein mit der anzahl der Karten mit denen der Gegner angreift.");
                    }
                }
            } else {
                if (!UserAmZug) {
                    Tipp.setText("Sie sind nicht am Zug!");
                } else if (!UserVerteidigung) {
                    Tipp.setText("Sie verteidigen sich nicht und mьssen angeifen (spielen)");
                } else if (!((Stapel.size() >= 2) && (UserStapel.size() < 4))) {
                    Tipp.setText("Sie mьssen zuerst neue Karten vom Stapel nehmen");
                }
            }

        }
    };

    private View.OnClickListener UserStapelB_Click = new View.OnClickListener() {
        public void onClick(View v) {
            int Wert = 0;
            for (int i = 0; i < UserAblage.size(); i++) {
                Wert += UserAblage.get(i).getWert();
            }
            Tipp.setText("Wert :" + Wert + "Karten Anzahl :" + UserAblage.size());
        }
    };

    private View.OnClickListener EnemyStapelB_Click = new View.OnClickListener() {
        public void onClick(View v) {
            int Wert = 0;
            for (int i = 0; i < EnemyAblage.size(); i++) {
                Wert += EnemyAblage.get(i).getWert();
            }
            Tipp.setText("Wert :" + Wert + "Karten Anzahl :" + EnemyAblage.size());
        }
    };

    private View.OnClickListener UserCardPlayed_Click = new View.OnClickListener() {
        public void onClick(View v) {
            Tipp.setText("Das sind die Karten, die Sie gespielt haben.");
        }
    };

    private View.OnClickListener EnemyCardPlayed_Click = new View.OnClickListener() {
        public void onClick(View v) {
            Tipp.setText("Das sind die Karten, die der Gegner gespielt hat.");
        }
    };

    private View.OnClickListener EnemyCard_Click = new View.OnClickListener() {
        public void onClick(View v) {
            Tipp.setText("Das sind die Karten des Gegners.");
        }
    };

    private View.OnClickListener UserCard1_Click = new View.OnClickListener() {
        public void onClick(View v) {
            if (UserAmZug) {
                for (int i =0;i < UserStapelSpielen.size();i++){
                    if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                            && UserStapel.get(0).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())){
                            tempAlreadySelected1 = true;
                        break;
                    }
                }
                if (tempAlreadySelected1){
                    //Deselect
                    Tipp.setText("UC1 deselected !");
                    for (int i = 0; i < UserStapel.size(); i++) {
                        if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                                && UserStapel.get(0).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())) {
                            UserStapelSpielen.remove(i);
                            break;
                        }
                    }
                }
                else {
                    //Select
                    Tipp.setText("UC1 selected !");
                    UserStapelSpielen.add(UserStapel.get(0));
                }
            } else {
                Tipp.setText("Sie sind nicht am Zug!");
            }
        }
    };
    private View.OnClickListener UserCard2_Click = new View.OnClickListener() {
        public void onClick(View v) {
            if (UserAmZug) {
                for (int i =0;i < UserStapelSpielen.size();i++){
                    if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                            && UserStapel.get(1).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())){
                        tempAlreadySelected2 = true;
                        break;
                    }
                }
                if (tempAlreadySelected2){
                    //Deselect
                    Tipp.setText("UC1 deselected !");
                    for (int i = 0; i < UserStapel.size(); i++) {
                        if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                                && UserStapel.get(1).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())) {
                            UserStapelSpielen.remove(i);
                            break;
                        }
                    }
                }
                else {
                    //Select
                    Tipp.setText("UC1 selected !");
                    UserStapelSpielen.add(UserStapel.get(1));
                }
            } else {
                Tipp.setText("Sie sind nicht am Zug!");
            }

        }
    };
    private View.OnClickListener UserCard3_Click = new View.OnClickListener() {
        public void onClick(View v) {
            if (UserAmZug) {
                for (int i =0;i < UserStapelSpielen.size();i++){
                    if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                            && UserStapel.get(2).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())){
                        tempAlreadySelected3 = true;
                        break;
                    }
                }
                if (tempAlreadySelected3){
                    //Deselect
                    Tipp.setText("UC1 deselected !");
                    for (int i = 0; i < UserStapel.size(); i++) {
                        if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                                && UserStapel.get(2).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())) {
                            UserStapelSpielen.remove(i);
                            break;
                        }
                    }
                }
                else {
                    //Select
                    Tipp.setText("UC1 selected !");
                    UserStapelSpielen.add(UserStapel.get(2));
                }
            } else {
                Tipp.setText("Sie sind nicht am Zug!");
            }

        }
    };
    private View.OnClickListener UserCard4_Click = new View.OnClickListener() {
        public void onClick(View v) {
            if (UserAmZug) {
                for (int i =0;i < UserStapelSpielen.size();i++){
                    if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                            && UserStapel.get(3).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())){
                        tempAlreadySelected4 = true;
                        break;
                    }
                }
                if (tempAlreadySelected4){
                    //Deselect
                    Tipp.setText("UC1 deselected !");
                    for (int i = 0; i < UserStapel.size(); i++) {
                        if (UserStapel.get(0).getKarte().equals(UserStapelSpielen.get(i).getKarte())
                                && UserStapel.get(3).getFarbe().equals(UserStapelSpielen.get(i).getFarbe())) {
                            UserStapelSpielen.remove(i);
                            break;
                        }
                    }
                }
                else {
                    //Select
                    Tipp.setText("UC1 selected !");
                    UserStapelSpielen.add(UserStapel.get(3));
                }
            } else {
                Tipp.setText("Sie sind nicht am Zug!");
            }
        }
    };

    private void ClearStacks() {
        Stapel.clear();
        UserStapel.clear();
        EnemyStapel.clear();
        UserStapelSpielen.clear();
        EnemyStapelSpielen.clear();
        UserAblage.clear();
        EnemyAblage.clear();
    }

    private View.OnClickListener Stapel_Click = new View.OnClickListener() {
        public void onClick(View v) {
                Boolean tempB = false;
                Tipp.setText("Stack Clicked ! Size : " + Stapel.size()
                        + ". Der Spieler welcher sich erfolgreich verteidigt oder angegriffen hat ziht die erste Karte danach wird abgewechselt. ");
                if (Stapel.isEmpty()) {
                    if (!UserStapelSpielen.isEmpty() && !EnemyStapelSpielen.isEmpty()) {
                        UserStapelSpielen.clear();
                        EnemyStapelSpielen.clear();
                        KartenAnzeigen();
                    }
                } else if ((UserStapel.size() < 4) && (EnemyStapel.size() < 4)) {
                    UserStapelSpielen.clear();
                    EnemyStapelSpielen.clear();
                    if (UserAmZug == true) {
                        KartenAusteilen(true);
                    } else {
                        KartenAusteilen(false);
                    }
                    KartenAnzeigen();
                }
                if (Stapel.size() == 0 && UserStapel.size() == 0 && EnemyStapel.size() == 0) {
                    if (UserAmZugLetztePartie) {
                        PunkteSpielVerteilenGewonnen();
                        if (Integer.parseInt(PointsUser.getText().toString()) >= 12) {
                            try {
                                messenger.Gewonnen(UserAcc.getUsername(), false);
                                messenger.Verloren(EnemyUser, false);
                            } catch (Exception e) {
                                Tipp.setText(".Gewonnen / .Verloren failed");
                            }
                        }
                        if (Integer.parseInt(PointsEnemy.getText().toString()) >= 12) {
                            try {
                                messenger.Verloren(UserAcc.getUsername(), false);
                                messenger.Gewonnen(EnemyUser, false);
                            } catch (Exception e) {
                                Tipp.setText(".Gewonnen / .Verloren failed");
                            }
                        }
                        if ((Integer.parseInt(PointsUser.getText().toString()) < 12) && (Integer.parseInt(PointsEnemy.getText().toString()) < 12)) {
                            try {
                                messenger.getNewStack36(EnemyUser, UserAcc.getUsername(), UserAmZugLetztePartie);
                            } catch (Exception e) {
                                Tipp.setText("getNewStack36 failed");
                            }
                        }
                    }
                }

        }
    };

    private View.OnClickListener Joker_Click = new View.OnClickListener() {
        public void onClick(View v) {
            Tipp.setText(
                    "Beim Verteidigen kann jede gegnerische Karte durch eine Karte, die dieselbe Farbe hat, wie die Trumpfkartenfarbe geschlagen werden.(AuЯer sie haben auch dieselbe Farbe dann gelten die normalen Prioritдtsregeln.)");
        }
    };

    private View.OnClickListener Menu1Click = new View.OnClickListener() {
        public void onClick(View v) {
            if (Menu1.getText().equals("Bluetooth")){
                Tipp.setText("Select between hosting or challenging.");
                Menu1.setText("Host");
                Menu2.setText("Challenge");
            }
            else if (Menu1.getText().equals("Host")){
                BSS_T = new BluetoothServerSocket_T(Main.this);
                BSS_T.start();
            }
        }
    };

    private View.OnClickListener Menu2Click = new View.OnClickListener() {
        public void onClick(View v) {
            if (Menu2.getText().equals("Internet")){
                Tipp.setText("Internet functionality not implemented yet.");
            }
            else if (Menu2.getText().equals("Challenge")){
                BCS_T = new BluetoothClientSocket_T(Main.this);
                if (BCS_T.ConstructorFinished) {
                    dialogManager.Challenge(BCS_T.pairedDevices);
                }
            }
        }
    };

    public void SpielGefunden(List<Cards> Stack, Boolean AmZug) {
        for (int i = 0; i < Stack.size(); i++) {
            Stapel.add(Stack.get(i));
        }
        ImSpiel = true;
        InitAmZug(AmZug);
        TrumpfkartenFarbe = Stapel.get(0).getFarbe();
        Stapel.add(Stapel.get(0));
        Stapel.remove(0);
        ShowPunkteAnzeigeButtons();
        KartenAnzeigen();
        UserAmZugLetztePartie = AmZug;
        Menu1.setText("Aufgeben");
        Menu2.setVisibility(View.INVISIBLE);
    }

    private void KartenAnzeigen() {
        int Size;
        ResetVisibility();
        if (!UserAblage.isEmpty()) {
            UserStapelB.setVisibility(View.VISIBLE);
            UserStapelB.setImageResource(R.mipmap.back);
        }
        if (!EnemyAblage.isEmpty()) {
            EnemyStapelB.setVisibility(View.VISIBLE);
            EnemyStapelB.setImageResource(R.mipmap.back);
        }
        if (!Stapel.isEmpty()) {
            Size = Stapel.size();
            Joker.setImageResource(getResId(Stapel.get(Size-1).getKarte() + Stapel.get(Size - 1).getFarbe(),R.mipmap.class));
            Joker.setVisibility(View.VISIBLE);
            if (Size >= 2) {
                StapelB.setVisibility(View.VISIBLE);
                StapelB.setImageResource(R.mipmap.back);
            }
        } else {
            StapelB.setVisibility(View.VISIBLE);
            StapelB.setImageResource(R.mipmap.ok);
            Joker.setImageResource(getResId(TrumpfkartenFarbe,R.mipmap.class));
            Joker.setVisibility(View.VISIBLE);
        }
        if (!UserStapel.isEmpty()) {
            Size = UserStapel.size();
            UserCard1.setImageResource(getResId(UserStapel.get(0).getKarte() + UserStapel.get(0).getFarbe(),R.mipmap.class));
            UserCard1.setVisibility(View.VISIBLE);
            if (Size >= 2) {
                UserCard2.setImageResource(getResId(UserStapel.get(1).getKarte() + UserStapel.get(1).getFarbe(),R.mipmap.class));
                UserCard2.setVisibility(View.VISIBLE);
            }
            if (Size >= 3) {
                UserCard3.setImageResource(getResId(UserStapel.get(2).getKarte() + UserStapel.get(2).getFarbe(),R.mipmap.class));
                UserCard3.setVisibility(View.VISIBLE);
            }
            if (Size == 4) {
                UserCard4.setImageResource(getResId(UserStapel.get(3).getKarte() + UserStapel.get(3).getFarbe(),R.mipmap.class));
                UserCard4.setVisibility(View.VISIBLE);
            }
        }

        if (!EnemyStapel.isEmpty()) {
            Size = EnemyStapel.size();
            EnemyCard1.setImageResource(getResId(EnemyStapel.get(0).getKarte() + EnemyStapel.get(0).getFarbe(),R.mipmap.class));
            EnemyCard1.setVisibility(View.VISIBLE);
            if (Size >= 2) {
                EnemyCard2.setImageResource(getResId(EnemyStapel.get(1).getKarte() + EnemyStapel.get(1).getFarbe(),R.mipmap.class));
                EnemyCard2.setVisibility(View.VISIBLE);
            }
            if (Size >= 3) {
                EnemyCard3.setImageResource(getResId(EnemyStapel.get(2).getKarte() + EnemyStapel.get(2).getFarbe(),R.mipmap.class));
                EnemyCard3.setVisibility(View.VISIBLE);
            }
            if (Size == 4) {
                EnemyCard4.setImageResource(getResId(EnemyStapel.get(3).getKarte() + EnemyStapel.get(3).getFarbe(),R.mipmap.class));
                EnemyCard4.setVisibility(View.VISIBLE);
            }
        }
        if (!UserStapelSpielen.isEmpty()) {
            Size = UserStapelSpielen.size();
            UserCard_Played1.setImageResource(getResId(UserStapelSpielen.get(0).getKarte() + UserStapelSpielen.get(0).getFarbe(),R.mipmap.class));
            UserCard_Played1.setVisibility(View.VISIBLE);
            if (Size >= 2) {
                UserCard_Played2.setImageResource(getResId(UserStapelSpielen.get(1).getKarte() + UserStapelSpielen.get(1).getFarbe(),R.mipmap.class));
                UserCard_Played2.setVisibility(View.VISIBLE);
            }
            if (Size >= 3) {
                UserCard_Played3.setImageResource(getResId(UserStapelSpielen.get(2).getKarte() + UserStapelSpielen.get(2).getFarbe(),R.mipmap.class));
                UserCard_Played3.setVisibility(View.VISIBLE);
            }
            if (Size == 4) {
                UserCard_Played4.setImageResource(getResId(UserStapelSpielen.get(3).getKarte() + UserStapelSpielen.get(3).getFarbe(),R.mipmap.class));
                UserCard_Played4.setVisibility(View.VISIBLE);
            }
        }
        if (!EnemyStapelSpielen.isEmpty()) {
            Size = EnemyStapelSpielen.size();
            EnemyCard_Played1.setImageResource(getResId( EnemyStapelSpielen.get(0).getKarte() +  EnemyStapelSpielen.get(0).getFarbe(),R.mipmap.class));
            EnemyCard_Played1.setVisibility(View.VISIBLE);
            if (Size >= 2) {
                EnemyCard_Played2.setImageResource(getResId( EnemyStapelSpielen.get(1).getKarte() +  EnemyStapelSpielen.get(1).getFarbe(),R.mipmap.class));
                EnemyCard_Played2.setVisibility(View.VISIBLE);
            }
            if (Size >= 3) {
                EnemyCard_Played3.setImageResource(getResId( EnemyStapelSpielen.get(2).getKarte() +  EnemyStapelSpielen.get(2).getFarbe(),R.mipmap.class));
                EnemyCard_Played3.setVisibility(View.VISIBLE);
            }
            if (Size == 4) {
                EnemyCard_Played4.setImageResource(getResId( EnemyStapelSpielen.get(3).getKarte() +  EnemyStapelSpielen.get(3).getFarbe(),R.mipmap.class));
                EnemyCard_Played4.setVisibility(View.VISIBLE);
            }
        }
    }

    private void ResetVisibility() {
        UserCard1.setVisibility(View.INVISIBLE);
        UserCard2.setVisibility(View.INVISIBLE);
        UserCard3.setVisibility(View.INVISIBLE);
        UserCard4.setVisibility(View.INVISIBLE);
        EnemyCard1.setVisibility(View.INVISIBLE);
        EnemyCard2.setVisibility(View.INVISIBLE);
        EnemyCard3.setVisibility(View.INVISIBLE);
        EnemyCard4.setVisibility(View.INVISIBLE);
        EnemyCard_Played1.setVisibility(View.INVISIBLE);
        EnemyCard_Played2.setVisibility(View.INVISIBLE);
        EnemyCard_Played3.setVisibility(View.INVISIBLE);
        EnemyCard_Played4.setVisibility(View.INVISIBLE);
        UserCard_Played1.setVisibility(View.INVISIBLE);
        UserCard_Played2.setVisibility(View.INVISIBLE);
        UserCard_Played3.setVisibility(View.INVISIBLE);
        UserCard_Played4.setVisibility(View.INVISIBLE);
        StapelB.setVisibility(View.INVISIBLE);
        Joker.setVisibility(View.INVISIBLE);
        UserStapelB.setVisibility(View.INVISIBLE);
        EnemyStapelB.setVisibility(View.INVISIBLE);
    }

    public static int getResId(String resName, Class<?> c) {

        try {
            Field idField = c.getDeclaredField(resName);
            return idField.getInt(idField);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }



    private int GetUserPartiePunkte() {
        int Wert = 0;
        for (int i = 0; i < UserAblage.size(); i++) {
            Wert += UserAblage.get(i).getWert();
        }
        return Wert;
    }

    private int GetEnemyPartiePunkte() {
        int Wert = 0;
        for (int i = 0; i < EnemyAblage.size(); i++) {
            Wert += EnemyAblage.get(i).getWert();
        }
        return Wert;
    }

    private boolean PunkteSpielVerteilenGewonnen() {
        int Punkte = 0;
        if ((GetUserPartiePunkte() + GetEnemyPartiePunkte()) != 120) {
            System.out.println("PunkteSpielVerteilen broken");
        } else if (GetUserPartiePunkte() == 120) {
            Punkte = Integer.parseInt(PointsUser.getText().toString());
            PointsUser.setText(Integer.toString(Punkte + 6));
            UserAmZugLetztePartie = true;
        } else if (GetUserPartiePunkte() >= 90) {
            Punkte = Integer.parseInt(PointsUser.getText().toString());
            PointsUser.setText(Integer.toString(Punkte + 4));
            UserAmZugLetztePartie = true;
        } else if (GetUserPartiePunkte() > 60) {
            Punkte = Integer.parseInt(PointsUser.getText().toString());
            PointsUser.setText(Integer.toString(Punkte + 2));
            UserAmZugLetztePartie = true;
        } else if (GetUserPartiePunkte() == 60) {
        } else if (GetEnemyPartiePunkte() == 120) {
            Punkte = Integer.parseInt(PointsEnemy.getText().toString());
            PointsEnemy.setText(Integer.toString(Punkte + 6));
            UserAmZugLetztePartie = false;
        } else if (GetEnemyPartiePunkte() >= 90) {
            Punkte = Integer.parseInt(PointsEnemy.getText().toString());
            PointsEnemy.setText(Integer.toString(Punkte + 4));
            UserAmZugLetztePartie = false;
        } else if (GetEnemyPartiePunkte() > 60) {
            Punkte = Integer.parseInt(PointsEnemy.getText().toString());
            PointsEnemy.setText(Integer.toString(Punkte + 2));
            UserAmZugLetztePartie = false;
        }
        ResetPunkte(false);
        return UserAmZugLetztePartie;
    }

    public void NextGame(List<Cards> Stack, Boolean AmZug) {
        if (!UserAmZugLetztePartie
                && (!(PointsUser.getText().equals("0")) || !(PointsEnemy.getText().equals("0")))) {
            PunkteSpielVerteilenGewonnen();
        }
        Stapel.clear();
        for (int i = 0; i < Stack.size(); i++) {
            Stapel.add(Stack.get(i));
        }
        UserStapel.clear();
        EnemyStapel.clear();
        UserStapelSpielen.clear();
        EnemyStapelSpielen.clear();
        UserAblage.clear();
        EnemyAblage.clear();
        InitAmZug(AmZug);
        TrumpfkartenFarbe = Stapel.get(0).getFarbe();
        Stapel.add(Stapel.get(0));
        Stapel.remove(0);
        ShowPunkteAnzeigeButtons();
        KartenAnzeigen();
    }

    private void ShowPunkteAnzeigeButtons() {
        PointsUser.setVisibility(View.VISIBLE);
        PointsEnemy.setVisibility(View.VISIBLE);
        Spielen.setVisibility(View.VISIBLE);
        Passen.setVisibility(View.VISIBLE);
        Schlagen.setVisibility(View.VISIBLE);
    }

    public void receiveCards(List<Cards> Stack, Boolean gepasst, Boolean gespielt, Boolean geschlagen) {
                if (gepasst) {
                    System.out.println("receiveCards gepasst");
                    for (int i = 0; i < Stack.size(); i++) {
                        EnemyStapelSpielen.add(Stack.get(i));
                    }
                    for (int a = 0; a < EnemyStapelSpielen.size(); a++) {
                        for (int i = 0; i < EnemyStapel.size(); i++) {
                            if (EnemyStapel.get(i).getKarte().equals(EnemyStapelSpielen.get(a).getKarte())
                                    && EnemyStapel.get(i).getFarbe().equals(EnemyStapelSpielen.get(a).getFarbe())) {
                                EnemyStapel.remove(i);
                            }
                        }
                    }
                    UserAmZug = true;
                    UserAngriff = true;
                    UserVerteidigung = false;
                    for (int i = 0; i < UserStapelSpielen.size(); i++) {
                        UserAblage.add(UserStapelSpielen.get(i));
                    }
                    for (int i = 0; i < EnemyStapelSpielen.size(); i++) {
                        UserAblage.add(EnemyStapelSpielen.get(i));
                    }
                    KartenAnzeigen();
                }
                if (gespielt) {
                    System.out.println("receiveCards gespielt");
                    if (!UserStapelSpielen.isEmpty() && !EnemyStapelSpielen.isEmpty()) {
                        StapelB.performClick();
                    }
                    for (int i = 0; i < Stack.size(); i++) {
                        EnemyStapelSpielen.add(Stack.get(i));
                    }
                    for (int a = 0; a < EnemyStapelSpielen.size(); a++) {
                        for (int i = 0; i < EnemyStapel.size(); i++) {
                            if (EnemyStapel.get(i).getKarte().equals(EnemyStapelSpielen.get(a).getKarte())
                                    && EnemyStapel.get(i).getFarbe().equals(EnemyStapelSpielen.get(a).getFarbe())) {
                                EnemyStapel.remove(i);
                            }
                        }
                    }
                    UserAmZug = true;
                    UserAngriff = false;
                    UserVerteidigung = true;
                    KartenAnzeigen();
                }
                if (geschlagen) {
                    System.out.println("receiveCards geschlagen");
                    for (int i = 0; i < Stack.size(); i++) {
                        EnemyStapelSpielen.add(Stack.get(i));
                    }
                    for (int a = 0; a < EnemyStapelSpielen.size(); a++) {
                        for (int i = 0; i < EnemyStapel.size(); i++) {
                            if (EnemyStapel.get(i).getKarte().equals(EnemyStapelSpielen.get(a).getKarte())
                                    && EnemyStapel.get(i).getFarbe().equals(EnemyStapelSpielen.get(a).getFarbe())) {
                                EnemyStapel.remove(i);
                            }
                        }
                    }
                    UserAmZug = false;
                    UserAngriff = false;
                    UserVerteidigung = false;
                    for (int i = 0; i < UserStapelSpielen.size(); i++) {
                        EnemyAblage.add(UserStapelSpielen.get(i));
                    }
                    for (int i = 0; i < EnemyStapelSpielen.size(); i++) {
                        EnemyAblage.add(EnemyStapelSpielen.get(i));
                    }
                    KartenAnzeigen();
                }
            }

    @Override
    public void onDialogMessage(String Message) {
        Tipp.setText(Message);
    }

    @Override
    public void StartBluetoothClientThread(String SelectedDevice) {
        BCS_T.SelectedDevice = SelectedDevice;
        BCS_T.start();
    }

    @Override
    public void CreateMessenger(BluetoothSocket socket, boolean imServer) {
        client = new Client(Main.this);

        if (imServer) {
            server = new Server(client);
        }

        messenger = new Messenger(socket,Main.this,imServer,server,client);
        if (server != null) {
            server.setMessenger(messenger);
        }
        messenger.start();
        messenger.getUsername();
    }

    @Override
    public void setUserAcc(String Username) {
        UserAcc = new User(Username);
        User = Username;
        UserName.setText (Username);
    }

    @Override
    public void getUsername() {
        messenger.SendUsername(User);
    }

    @Override
    public void SendUsername(String EnemyUsername) {
        EnemyUser = EnemyUsername;
        EnemyName.setText(EnemyUsername);
    }

    @Override
    public void CSpielGefunden(List<Cards> Stack, Boolean AmZug) {
        SpielGefunden(Stack,AmZug);
    }
}
