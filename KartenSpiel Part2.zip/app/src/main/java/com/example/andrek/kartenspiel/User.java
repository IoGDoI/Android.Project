package com.example.andrek.kartenspiel;

import java.util.List;

public class User {
    private String Username;

    public User(String Username){

        this.Username = Username;
    }

    public String getUsername(){

        return Username;
    }

}