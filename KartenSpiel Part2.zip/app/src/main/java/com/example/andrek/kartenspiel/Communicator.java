package com.example.andrek.kartenspiel;

import android.bluetooth.BluetoothSocket;

import java.util.List;

/**
 * Created by AndreK on 03.12.2016.
 */

public interface Communicator {
    public void onDialogMessage(String Message);
    public void StartBluetoothClientThread(String SelectedDevice);
    public void CreateMessenger(BluetoothSocket socket,boolean imServer);
    public void setUserAcc(String Username);
    public void getUsername();
    public void SendUsername(String EnemyUsername);
    public void CSpielGefunden(List<Cards> Stack, Boolean AmZug);
}