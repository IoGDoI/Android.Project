package com.example.andrek.kartenspiel;

import android.app.Activity;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by AndreK on 04.12.2016.
 */

public class Messenger extends Thread{
    public BluetoothSocket socket;
    public Activity activity;
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;
    boolean ImServer = false;
    public Communicator communicator;
    public Server server;
    public Client client;

    public Messenger(BluetoothSocket Socket, Activity mainActivity, boolean imServer, Server myServer, Client myClient){
        communicator = (Communicator) mainActivity;
        socket = Socket;
        activity = mainActivity;
        ImServer = imServer;
        InputStream tmpIn = null;
        OutputStream tmpOut = null;
        server = myServer;
        client = myClient;

        try {
            tmpIn = socket.getInputStream();
            tmpOut = socket.getOutputStream();
        } catch (IOException e) {
            communicator.onDialogMessage("Messenger getInputStream()getOutputStream() failed");
        }

        mmInStream = tmpIn;
        mmOutStream = tmpOut;
    }

    public void run() {
        byte[] buffer = new byte[1024];  // buffer store for the stream
        int bytes; // bytes returned from read()

        while (true) {
            try {
                bytes = mmInStream.read(buffer);
                HandleMessage(read(buffer));
            } catch (IOException e) {
                activity.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.onDialogMessage("Messenger read failed");
                    }
                });
                break;
            }
        }
    }

    public void write(String myMessage) {
        byte[] buffer = new byte[1024];
        buffer = myMessage.getBytes();
        try {
            mmOutStream.write(buffer);
        } catch (IOException e) { }
    }

    public String read(byte[] buffer) {
        String myString = new String(buffer);
        return myString;
    }

    /* Call this from the main activity to shutdown the connection */
    public void cancel() {
        try {
            socket.close();
        } catch (IOException e) { }
    }

    private void HandleMessage(String message){
        final String wtf = message;
        //communicator.onDialogMessage(message);
        String[] parts = message.split(";");
        boolean temp = false;
        //Server Part ------------------------------------------------------------------------------
        if (parts[0].equals("getNewStack36")){
            if (parts[3].equals("True")){
                temp = true;
            }
            else if (parts[3].equals("False")){
                temp = false;
            }
            server.getNewStack36(parts[1],parts[2],temp);
        }
        else if (parts[0].equals("Gewonnen")){
            if (parts[2].equals("True")){
                temp = true;
            }
            else if (parts[2].equals("False")){
                temp = false;
            }
            server.Gewonnen(parts[1],temp);
        }
        else if (parts[0].equals("Verloren")){
            if (parts[2].equals("True")){
                temp = true;
            }
            else if (parts[2].equals("False")){
                temp = false;
            }
            server.Verloren(parts[1],temp);
        }
        else if (parts[0].equals("SendCards")){
            String[] tempParts  = new String[72];
            tempParts = parts[3].split(":");
            server.SendCards(parts[1],parts[2],decodeCardsArrayEazy(tempParts),stringToBool(parts[4]),stringToBool(parts[5]),stringToBool(parts[6]));
        }
        else if (parts[0].equals("Aufgeben")){
            server.Aufgeben(parts[1],parts[2]);
        }
        //Server Part End------------------------------------------------------------------------------
        else if (parts[0].equals("CGewonnen")){
            client.CGewonnen();
        }
        else if (parts[0].equals("CVerloren")){
            client.CVerloren();
        }
        else if (parts[0].equals("EnemySurrendered")){
            client.EnemySurrendered();
        }
        else if (parts[0].equals("setNewStack36")){
            String[] tempParts  = new String[72];
            tempParts = parts[1].split(":");
            client.setNewStack36(decodeCardsArrayEazy(tempParts),stringToBool(parts[2]));
        }
        else if (parts[0].equals("SpielGefunden")){
            String[] tempParts  = new String[72];
            tempParts = parts[1].split(":");
            client.SpielGefunden(decodeCardsArrayEazy(tempParts),stringToBool(parts[2]));
        }
        else if (parts[0].equals("receiveCards")){
            String[] tempParts  = new String[72];
            tempParts = parts[1].split(":");
            client.receiveCards(decodeCardsArrayEazy(tempParts),stringToBool(parts[2]),stringToBool(parts[3]),stringToBool(parts[4]));
        }
        else if (parts[0].equals("getUsername")){
            client.getUsername();
        }
        else if (parts[0].equals("SendUsername")){
            client.SendUsername(parts[1]);
        }
        //Client Part End------------------------------------------------------------------------------
    }

    public String boolToString(boolean bool){
        if (bool == true){
            return "True;";
        }
        else if (bool == false){
            return "False;";
        }
        else {
            //Toast.makeText(MainActivity.this ,"boolToString fatal error" ,Toast.LENGTH_SHORT).show();
            return "False;";
        }
    }

    public boolean stringToBool(String bool){
        if (bool.equals("True")){
            return true;
        }
        else if (bool.equals("False")){
            return false;
        }
        else {
            //Toast.makeText(MainActivity.this ,"stringToBool fatal error" ,Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public String encodeCards (Cards card){
        return (card.getKarte() +":"+ card.getFarbe() + ":");
    }


    public String encodeCardsArray(List<Cards> cards){
        String result = "";
        for (int i = 0 ;i < cards.size() ;i++){
            result += encodeCards(cards.get(i));
        }
        result += ";";
        return result;
    }


    public List<Cards> decodeCardsArrayEazy(String[] cards){
        List<Cards> result = new ArrayList<Cards>();
        for (int i = 0 ;i < cards.length;i+=2){
            if (cards[i] == null ||cards[i].equals("") ){
                break;
            }
            result.add(new Cards(cards[i],cards[i+1]));
        }
        return result;
    }

    public void SendCards(String enemyUser, String username, List<Cards> userStapelSpielen, boolean b, boolean b1, boolean b2) {
    }

    public void Gewonnen(String username, boolean b) {
    }

    public void Verloren(String enemyUser, boolean b) {
    }

    public void getNewStack36(String enemyUser, String username, boolean userAmZugLetztePartie) {

    }

    public void getUsername(){
        String Message = "getUsername;";
        write(Message);
    }

    public void SendUsername(String Username){
        if (ImServer) {
            server.SendUsername(Username);
        }
        else{
            String Message = "SendUsername;";
            Message += Username;
            write(Message);
        }
    }
}
