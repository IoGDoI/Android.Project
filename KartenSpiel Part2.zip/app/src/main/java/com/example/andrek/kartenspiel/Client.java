package com.example.andrek.kartenspiel;

import android.app.Activity;

import java.util.List;

/**
 * Created by AndreK on 04.12.2016.
 */

public class Client {
    Activity activity;
    Communicator communicator;
    Messenger messenger;
    public Client(Activity myActivity){
        activity = myActivity;
        communicator = (Communicator) activity;
    }

    void setNewStack36(List<Cards> Stack, Boolean AmZug){
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.onDialogMessage("setNewStack36");
            }
        });
    }
    void SpielGefunden(final List<Cards> Stack, final Boolean AmZug){
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.onDialogMessage("SpeilGefunden");
                communicator.CSpielGefunden(Stack,AmZug);
            }
        });
    }
    void receiveCards(List<Cards> Stack, Boolean gepasst, Boolean gespielt, Boolean geschlagen){
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.onDialogMessage("receiveCards");
            }
        });
    }
    void CGewonnen(){
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.onDialogMessage("CGewonnen");
            }
        });
    }
    void CVerloren() {
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.onDialogMessage("CVerloren");
            }
        });
    }
    void EnemySurrendered() {
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.onDialogMessage("EnemySurrendered");
            }
        });
    }

    public void getUsername() {
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.getUsername();
            }
        });
    }

    public void SendUsername(String EnemyUsername) {
        final String enemyUsername = EnemyUsername;
        activity.runOnUiThread(new Runnable() {
            public void run() {
                communicator.SendUsername(enemyUsername);
            }
        });
    }
}
