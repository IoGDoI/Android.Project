package com.example.andrek.kartenspiel;

import java.io.Serializable;

public class Cards{
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String Karte;
    private String Farbe;
    private int Prio;
    private int Wert;

    Cards(String Karte,String Farbe){
        this.Karte = Karte;
        this.Farbe = Farbe;
        SetWertPrio();
    }

    public String getKarte(){
        return Karte;
    }
    public String getFarbe(){
        return Farbe;
    }
    public int getWert(){
        return Wert;
    }
    public int getPrio(){
        return Prio;
    }
    private void SetWertPrio(){
        if (Karte.equals("k6")){
            Wert = 0;
            Prio = 1;
        }
        else if (Karte.equals("k7")){
            Wert = 0;
            Prio = 2;
        }
        else if (Karte.equals("k8")){
            Wert = 0;
            Prio = 3;
        }
        else if (Karte.equals("k9")){
            Wert = 0;
            Prio = 4;
        }
        else if (Karte.equals("kb")){
            Wert = 2;
            Prio = 5;
        }
        else if (Karte.equals("kd")){
            Wert = 3;
            Prio = 6;
        }
        else if (Karte.equals("kk")){
            Wert = 4;
            Prio = 7;
        }
        else if (Karte.equals("k10")){
            Wert = 10;
            Prio = 8;
        }
        else if (Karte.equals("ka")){
            Wert = 11;
            Prio = 9;
        }
    }
}