package com.example.andrek.kartenspiel;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;

/**
 * Created by AndreK on 03.12.2016.
 */

public class BluetoothServerSocket_T extends Thread{
    private BluetoothSocket mmSocket = null;
    private BluetoothDevice mmDevice = null;

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothServerSocket mmServerSocket = null;
    private String NAME = "KartenSpiel";
    private UUID MY_UUID;
    private String uuid_string = "54947df8-0e9e-4471-a2f9-9af509fb5889";
    private boolean OK = true;
    private boolean ConstructorFinished = false;
    Communicator communicator ;
    Set<BluetoothDevice> pairedDevices = null;
    Activity MainAct ;
    BluetoothSocket socket = null;


    public BluetoothServerSocket_T(Activity activity) {
        communicator = (Communicator) activity;
        MainAct = activity;
        BluetoothSocket tmp = null;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        MY_UUID = UUID.fromString(uuid_string);
        BluetoothServerSocket tmpSS = null;

        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
            communicator.onDialogMessage("Device does not support Bluetooth");
            OK = false;
        }
        else if (OK && !mBluetoothAdapter.isEnabled()) {
            communicator.onDialogMessage("enabeling Bluetooth");
            mBluetoothAdapter.enable();
            OK = false;
        }
        if (OK) {
            pairedDevices = mBluetoothAdapter.getBondedDevices();
            // If there are paired devices
            if (pairedDevices.size() == 0) {
                communicator.onDialogMessage("There are no Paired Devices");
                OK = false;
            }
        }
        if(OK) {
            //Start Server
            try {
                tmpSS = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
            } catch (IOException e) {
                OK = false;
            }
            mmServerSocket = tmpSS;
            ConstructorFinished = true;
        }
    }

    public void run() {

        // Keep listening until exception occurs or a socket is returned
        while (true) {// sciebo
            try {
                MainAct.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.onDialogMessage("hosting ...");
                    }
                });
                socket = mmServerSocket.accept();
            } catch (IOException e) {
                MainAct.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.onDialogMessage("mmServerSocket.accept() failed");
                    }
                });
                cancel();
                break;
            }
            // If a connection was accepted
            if (socket != null) {
                // Do work to manage the connection (in a separate thread)
                MainAct.runOnUiThread(new Runnable() {
                    public void run() {
                        communicator.CreateMessenger(socket, false);
                        communicator.onDialogMessage("Connection established");
                    }
                });
                break;
            }
        }

    }

    /** Will cancel the listening socket, and cause the thread to finish */
    public void cancel() {
        try {
            mmServerSocket.close();
        } catch (IOException e) { }
    }

}
