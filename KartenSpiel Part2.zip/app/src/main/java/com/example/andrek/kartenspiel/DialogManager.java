package com.example.andrek.kartenspiel;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;

import java.util.Random;
import java.util.Set;

/**
 * Created by L K on 05.12.2016.
 */

public class DialogManager {
    Activity activity;
    FragmentManager fragmentManager;
    Communicator communicator;
    public DialogManager(Activity myActivity, FragmentManager myFragmentManager){
        activity = myActivity;
        fragmentManager = myFragmentManager;
        communicator = (Communicator) myActivity;
    }

    public void setUsernameDialog() {
        DialogFragment newFragment = new DialogSetUsername(communicator);
        newFragment.show(fragmentManager , "SetUsername");
    }

    public void Challenge(Set<BluetoothDevice> pairedDevices){
        DialogFragment newFragment = new DialogChallenge(communicator);

        Bundle args = new Bundle();
        String[] stringArray = new String[pairedDevices.size()];
        int i = 0;

        for (BluetoothDevice btd : pairedDevices) {
            stringArray[i] = btd.getName();
            i++;
        }
        args.putStringArray("Devices", stringArray);
        newFragment.setArguments(args);

        newFragment.show(fragmentManager, "ChallengeDialog");
    }
}

class DialogSetUsername extends DialogFragment {
    Communicator communicator ;

    public DialogSetUsername(Communicator myCommunicator){
        communicator = myCommunicator;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        setCancelable(false);
        final EditText input = new EditText(getActivity());
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        CharSequence cs = "User-";
        Random r = new Random ();
        int i = r.nextInt(100);
        cs = cs + Integer.toString(i);
        input.setText(cs);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                communicator.setUserAcc(input.getText().toString());
                dismiss();
            }
        });
        builder.setTitle("Enter a Username");
        // Create the AlertDialog object and return it
        return builder.create();
    }
}

class DialogChallenge extends DialogFragment{
    Communicator communicator ;

    public DialogChallenge(Communicator myCommunicator){
        communicator = myCommunicator;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        setCancelable(false);
        final String[] stringArray;
        stringArray = getArguments().getStringArray("Devices");
        builder.setItems(stringArray, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                communicator.onDialogMessage("Selected Device : "+ stringArray[i]);
                communicator.StartBluetoothClientThread(stringArray[i]);
                dismiss();
            }
        });
        builder.setTitle("Select Device");
        // Create the AlertDialog object and return it
        return builder.create();
    }
}